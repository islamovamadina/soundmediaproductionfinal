Place your audio file here as:
- song.mp3   (recommended)
or:
- song.wav
- song.ogg

If your filename differs, update it in sketch.js:
  loadSound('assets/song.mp3');
