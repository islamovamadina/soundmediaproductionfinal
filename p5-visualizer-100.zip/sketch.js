// Sound Visualizer — Final Project Template
// Key rubric items covered:
// 1) Audio load + play/pause via click (interaction) ✅
// 2) Analysis objects: p5.Amplitude + p5.FFT ✅
// 3) Data->visual mapping (size + color/alpha + rotation/position) ✅
// 4) 2+ shapes (ellipse + rect + line) ✅
// 5) Scaling tuned + constrained ✅
// 6) Readable code + comments (3+ places) ✅

let song;
let amp, fft;

let isPlaying = false;
let mode = 0;     // 0: orbit spectrum, 1: bars + pulse
let paletteId = 0;

function preload() {
  // NOTE: Put your audio file in assets/song.mp3
  // You may use .wav or .ogg too (update the filename accordingly).
  song = loadSound('assets/song.mp3');
}

function setup() {
  createCanvas(windowWidth, windowHeight);
  angleMode(RADIANS);

  // Analysis objects (Amplitude + FFT)
  amp = new p5.Amplitude();
  fft = new p5.FFT(0.9, 1024);

  // Optional: lower amplitude sensitivity if your track is loud
  amp.smooth(0.9);

  // Visual defaults
  noCursor();
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
}

function mousePressed() {
  // Browser autoplay policy requires user gesture
  userStartAudio();

  if (!song.isLoaded()) return;

  if (song.isPlaying()) {
    song.pause();
    isPlaying = false;
  } else {
    song.loop();
    isPlaying = true;
  }
}

function keyPressed() {
  if (key === 'm' || key === 'M') mode = (mode + 1) % 2;
  if (key === '1') paletteId = 0;
  if (key === '2') paletteId = 1;

  // Bonus: quick restart
  if (key === 'r' || key === 'R') {
    if (song.isLoaded()) {
      song.stop();
      song.loop();
      isPlaying = true;
    }
  }
}

function draw() {
  // --- Audio analysis values ---
  // Level typically ~0..0.3 depending on track
  const level = amp.getLevel();
  const a = constrain(map(level, 0, 0.30, 40, 220), 40, 220); // alpha reacts to volume ✅

  const spectrum = fft.analyze(); // 0..255
  const bass = fft.getEnergy("bass");     // 0..255
  const mid  = fft.getEnergy("mid");      // 0..255
  const tre  = fft.getEnergy("treble");   // 0..255

  // --- Color palettes (2 options) ---
  // Palette 0: cyber (cyan/magenta/gold), Palette 1: cinematic (amber/ice/indigo)
  const pal = getPalette(paletteId, a);
  const bg  = pal.bg;

  // Background with slight trail for smoothness (completeness polish)
  background(bg[0], bg[1], bg[2], 255);

  // Center point + dynamic radius scaling
  const cx = width * 0.5;
  const cy = height * 0.5;

  // Size (classic)
  const pulse = map(level, 0, 0.30, 20, min(width, height) * 0.25);
  const pulse2 = map(bass, 0, 255, 10, min(width, height) * 0.35);

  // Rotation reacts to mid energy ✅
  const rot = map(mid, 0, 255, 0, TWO_PI);

  if (mode === 0) {
    drawOrbitSpectrum(cx, cy, spectrum, bass, mid, tre, pulse, pulse2, rot, pal);
  } else {
    drawBarsAndPulse(cx, cy, spectrum, bass, mid, tre, pulse, pulse2, rot, pal);
  }

  // Minimal HUD marker
  drawStatusDot(isPlaying, pal);
}

function getPalette(id, a) {
  if (id === 1) {
    return {
      bg: [10, 12, 28],
      bass: color(255, 176, 64, a),   // amber
      mid: color(160, 220, 255, a),   // ice
      tre: color(140, 120, 255, a),   // indigo glow
      line: color(255, 255, 255, constrain(a - 40, 20, 160))
    };
  }
  // default (cyber)
  return {
    bg: [8, 10, 18],
    bass: color(255, 200, 60, a),    // gold
    mid: color(80, 220, 255, a),     // cyan
    tre: color(255, 80, 220, a),     // magenta
    line: color(255, 255, 255, constrain(a - 40, 20, 160))
  };
}

function drawOrbitSpectrum(cx, cy, spectrum, bass, mid, tre, pulse, pulse2, rot, pal) {
  push();
  translate(cx, cy);
  rotate(rot);

  // 1) Bass pulse circle (ellipse) ✅
  noStroke();
  fill(pal.bass);
  ellipse(0, 0, pulse2 * 1.15, pulse2 * 1.15);

  // 2) Mid ring (rects orbiting) ✅
  const ringR = pulse + 60;
  const n = 96;
  for (let i = 0; i < n; i++) {
    const idx = floor(map(i, 0, n - 1, 0, spectrum.length - 1));
    const v = spectrum[idx]; // 0..255
    const h = map(v, 0, 255, 4, 90); // scaling tuned ✅

    const ang = (TWO_PI * i) / n;
    const x = cos(ang) * ringR;
    const y = sin(ang) * ringR;

    push();
    translate(x, y);
    rotate(ang + rot * 0.3);

    // Color by band emphasis
    if (idx < spectrum.length * 0.33) fill(pal.bass);
    else if (idx < spectrum.length * 0.66) fill(pal.mid);
    else fill(pal.tre);

    rectMode(CENTER);
    rect(0, 0, 6, h, 3); // rect ✅
    pop();
  }

  // 3) Treble sparks (lines) ✅
  stroke(pal.tre);
  strokeWeight(1.2);
  const sparkCount = floor(map(tre, 0, 255, 8, 42));
  for (let i = 0; i < sparkCount; i++) {
    const ang = random(TWO_PI);
    const r1 = ringR + random(10, 60);
    const r2 = r1 + random(10, 90);
    line(cos(ang) * r1, sin(ang) * r1, cos(ang) * r2, sin(ang) * r2);
  }

  pop();
}

function drawBarsAndPulse(cx, cy, spectrum, bass, mid, tre, pulse, pulse2, rot, pal) {
  // Spectrum bars at bottom
  const bars = 128;
  const margin = 40;
  const w = (width - margin * 2) / bars;

  for (let i = 0; i < bars; i++) {
    const idx = floor(map(i, 0, bars - 1, 0, spectrum.length - 1));
    const v = spectrum[idx];
    const h = map(v, 0, 255, 2, height * 0.45); // tuned scaling ✅

    // Color zones: bass/mid/treble
    let c = pal.mid;
    if (idx < spectrum.length * 0.33) c = pal.bass;
    else if (idx >= spectrum.length * 0.66) c = pal.tre;

    noStroke();
    fill(c);
    rect(margin + i * w, height - margin - h, w * 0.85, h, 2);
  }

  // Center pulse circle
  push();
  translate(cx, cy);
  rotate(rot * 0.35);

  noStroke();
  fill(pal.bass);
  ellipse(0, 0, pulse2, pulse2);

  // Mid rotating square
  stroke(pal.line);
  strokeWeight(2);
  noFill();
  const sq = pulse + 120;
  rectMode(CENTER);
  rect(0, 0, sq, sq, 14);

  // Treble halo
  noStroke();
  fill(pal.tre);
  ellipse(0, 0, pulse * 0.55, pulse * 0.55);

  pop();
}

function drawStatusDot(isPlaying, pal) {
  push();
  noStroke();
  fill(isPlaying ? pal.mid : pal.line);
  circle(width - 22, 22, 10);
  pop();
}
